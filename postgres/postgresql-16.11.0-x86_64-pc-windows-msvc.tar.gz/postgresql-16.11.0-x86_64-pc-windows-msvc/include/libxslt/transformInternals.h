/*
 * Summary: set of internal interfaces for the XSLT engine transformation part.
 *
 * Copy: See Copyright for the status of this software.
 *
 * Author: David Kilzer <ddkilzer@apple.com>
 */

void xsltCleanupSourceDoc(xmlDocPtr doc);
